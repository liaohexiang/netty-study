package com.imooc.netty.ex12.thread;

public class Constant {
    public static final int PORT = 8000;
}