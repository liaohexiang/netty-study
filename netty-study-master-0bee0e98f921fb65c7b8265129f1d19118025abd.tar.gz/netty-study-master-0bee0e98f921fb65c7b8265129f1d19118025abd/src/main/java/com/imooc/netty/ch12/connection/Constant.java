package com.imooc.netty.ch12.connection;

/**
 * @author 闪电侠
 */
public class Constant {
    static final int BEGIN_PORT = 8000;
    static final int N_PORT = 100;
}