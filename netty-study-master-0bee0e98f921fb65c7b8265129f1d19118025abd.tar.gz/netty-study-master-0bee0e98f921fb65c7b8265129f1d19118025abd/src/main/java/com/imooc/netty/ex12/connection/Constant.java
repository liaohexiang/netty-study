package com.imooc.netty.ex12.connection;

public class Constant {
    //开始端口号
    static final int BEGIN_PORT = 8000;
    //绑定端口数量
    static final int N_PORT = 100;
}